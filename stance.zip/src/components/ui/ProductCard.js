const ProductCard = () => {
  return (
    <div className="product-card">
      ProductCard
      </div>
  )
}

export default ProductCard