const Runnlng = () => {
  return (
    <div className="runnlng">
      Runnlng
      </div>
  )
}

export default Runnlng