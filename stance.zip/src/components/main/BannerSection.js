const BannerSection = () => {
  return (
    <section id="banner">
      BannerSection
      </section>
  )
}

export default BannerSection