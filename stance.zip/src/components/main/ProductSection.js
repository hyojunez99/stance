const ProductSection = () => {
  return (
    <section id="product">
      ProductSection
      </section>
  )
}

export default ProductSection