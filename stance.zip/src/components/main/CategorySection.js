const CategorySection = () => {
  return (
    <section id="category">
      CategorySection
      </section>
  )
}

export default CategorySection