const Gnb = () => {
  return (
    <nav>Gnb</nav>
  )
}

export default Gnb