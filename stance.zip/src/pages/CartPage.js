const CartPage = () => {
  return (
    <div className="cart-page">
      CartPage
      </div>
  )
}

export default CartPage