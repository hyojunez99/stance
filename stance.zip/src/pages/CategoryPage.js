const CategoryPage = () => {
  return (
    <div className="category-page">
      CategoryPage
      </div>
  )
}

export default CategoryPage